import streamlit as st
import google.generativeai as genai
import faiss
import pickle
import os
from sentence_transformers import SentenceTransformer
from pypdf import PdfReader
import re

# =====================================
# PAGE CONFIG
# =====================================

st.set_page_config(
    page_title="AI Study Companion",
    page_icon="📚",
    layout="wide"
)

st.title("📚 AI Study Companion")

# =====================================
# CUSTOM CSS FOR NEON LAYOUT
# =====================================
st.markdown(
    """
    <style>
    /* General body and app background */
    .stApp {
        background-color: #0A001A; /* Very dark blue-purple background */
        color: #E0FFFF; /* Light cyan for general text */
        font-family: 'Roboto Mono', monospace; /* Professional techy font */
    }

    body {
        background-color: #0A001A; /* Ensure body matches app background */
        color: #E0FFFF; /* Light cyan for general text */
        font-family: 'Roboto Mono', monospace;
    }

    /* Headers */
    .stMarkdown h1, .stMarkdown h2, .stMarkdown h3, .stMarkdown h4, .stMarkdown h5, .stMarkdown h6 {
        color: #8A2BE2; /* Blue violet for headers (purple neon) */
        text-shadow: 0 0 10px #DA70D6; /* Orchid glow */
    }

    /* Buttons */
    .stButton>button {
        background-color: #8A2BE2; /* Blue violet buttons */
        color: #FFFFFF; /* White text on buttons */
        border: 2px solid #DA70D6;
        box-shadow: 0 0 15px #DA70D6; /* More prominent glow */
        transition: all 0.3s ease; /* Smooth transition on hover */
    }
    .stButton>button:hover {
        background-color: #9370DB; /* Medium Purple on hover */
        box-shadow: 0 0 20px #BA55D3, 0 0 30px #BA55D3; /* Enhanced glow on hover */
    }

    /* Text Inputs */
    .stTextInput>div>div>input {
        background-color: #1A0033; /* Darker purple for input fields */
        color: #ADD8E6; /* Light Blue for input text */
        border: 1px solid #8A2BE2;
        box-shadow: 0 0 5px #DA70D6;
        padding: 10px;
    }

    /* Selectbox */
    .stSelectbox>div>div>div {
        background-color: #1A0033; /* Darker purple for selectbox */
        color: #FFA07A; /* Light Salmon for selectbox text */
        border: 1px solid #9370DB;
        box-shadow: 0 0 5px #BA55D3;
    }
    .stSelectbox>div>div>div:hover {
        border-color: #8A2BE2; /* Slightly different on hover */
        box-shadow: 0 0 8px #9370DB;
    }

    /* Expander Headers (e.g., "Retrieved Notes", "Show Answer") */
    .streamlit-expanderHeader {
        background-color: #1A0033; /* Darker purple */
        color: #ADD8E6; /* Light Blue for expander headers */
        border-radius: 5px;
        border: 1px solid #483D8B;
        margin-top: 10px;
        padding: 10px;
        box-shadow: 0 0 5px #6A5ACD;
    }

    /* Chat Messages */
    .stChatMessage {
        background-color: #1A0033; /* Dark purple for chat messages */
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 10px;
        border: 1px solid #6A5ACD; /* Slate Blue border */
        box-shadow: 0 0 5px #6A5ACD;
    }
    .stChatMessage.st-chat-message-user {
        background-color: #0A001A; /* Slightly different background for user */
        border: 1px solid #ADD8E6; /* Light Blue border for user */
        box-shadow: 0 0 5px #ADD8E6;
    }
    .stChatMessage.st-chat-message-assistant {
        background-color: #1A0033;
        border: 1px solid #DDA0DD; /* Plum border for assistant */
        box-shadow: 0 0 5px #DDA0DD;
    }

    /* Warnings, Success, Info messages */
    .stAlert {
        background-color: #1A0033;
        border: 1px solid;
        border-radius: 5px;
        padding: 10px;
        margin-top: 10px;
        box-shadow: 0 0 5px;
    }
    .stAlert.success {
        border-color: #32CD32; /* Lime Green */
        color: #32CD32;
        box-shadow: 0 0 8px #32CD32;
    }
    .stAlert.warning {
        border-color: #FFD700; /* Gold */
        color: #FFD700;
        box-shadow: 0 0 8px #FFD700;
    }
    .stAlert.info {
        border-color: #1E90FF; /* Dodger Blue */
        color: #1E90FF;
        box-shadow: 0 0 8px #1E90FF;
    }

    /* General Markdown text color (important for quiz options) */
    .stMarkdown {
        color: #E0FFFF; /* Ensure general markdown text is light cyan */
    }

    /* Quiz Question Stem */
    .stMarkdown strong {
        color: #ADD8E6; /* Light Blue to make question stem stand out */
        text-shadow: 0 0 5px #ADD8E6;
    }

    /* Side bar */
    .stSidebar {
        background-color: #050010; /* Slightly darker sidebar background */
        border-right: 1px solid #8A2BE2;
        box-shadow: 0 0 10px #DA70D6;
    }
    .stSidebar h2 {
        color: #DA70D6;
        text-shadow: 0 0 8px #DA70D6;
    }

    /* Uploader */
    .stFileUploader label {
        color: #E0FFFF;
    }
    .stFileUploader button {
        background-color: #483D8B; /* Dark Slate Blue for upload button */
        color: #FFFFFF;
        border: 2px solid #6A5ACD;
        box-shadow: 0 0 10px #6A5ACD;
    }
    .stFileUploader button:hover {
        background-color: #584B9A;
        box-shadow: 0 0 15px #7B68EE;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# =====================================
# SESSION STATE INITIALIZATION
# =====================================

if "messages" not in st.session_state:
    st.session_state.messages = []

if "processed_kb" not in st.session_state:
    st.session_state.processed_kb = False

if "faiss_index" not in st.session_state:
    st.session_state.faiss_index = None

if "chunks" not in st.session_state:
    st.session_state.chunks = []

# =====================================
# CLEAR CHAT AND KNOWLEDGE BASE
# =====================================

if st.button("🗑 Clear Chat & Notes"): # Clear Chat and Notes button
    st.session_session.messages = []
    st.session_state.processed_kb = False
    st.session_state.faiss_index = None
    st.session_state.chunks = []
    st.success("Chat history and loaded notes cleared.")
    st.rerun()

# =====================================
# GEMINI CONFIGURATION
# =====================================
try:
    API_KEY = st.secrets["GOOGLE_API_KEY"]
except KeyError:
    st.error("Google API Key not found in Streamlit secrets. Please add it.")
    st.stop()

genai.configure(api_key=API_KEY)

gemini = genai.GenerativeModel("gemini-2.5-flash")

# =====================================
# LOAD EMBEDDING MODEL
# =====================================

@st.cache_resource
def load_embedding_model():
    return SentenceTransformer("all-MiniLM-L6-v2")

embed_model = load_embedding_model()

# =====================================
# TEXT CLEANING FUNCTION
# =====================================

def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.replace("\uf0b7", " ")
    text = text.replace("\uf020", " ")
    text = re.sub(r'[\ud800-\udfff]', '', text)
    text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

# =====================================
# PDF UPLOADER AND PROCESSING
# =====================================

with st.sidebar:
    st.header("Upload Your Study Notes")
    uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")

    if uploaded_file is not None and not st.session_state.processed_kb:
        with st.spinner("Processing PDF notes..."):
            all_text = ""
            pdf_reader = PdfReader(uploaded_file)
            for page in pdf_reader.pages:
                text = page.extract_text()
                if text:
                    all_text += text + "\n"

            # Chunking text
            chunk_size = 1000
            overlap = 200
            raw_chunks = []
            start = 0
            while start < len(all_text):
                end = start + chunk_size
                raw_chunks.append(all_text[start:end])
                start += chunk_size - overlap

            clean_chunks = [clean_text(c) for c in raw_chunks]
            st.session_state.chunks = [c for c in clean_chunks if c]

            if st.session_state.chunks:
                # Generate embeddings
                embeddings = embed_model.encode(
                    st.session_state.chunks,
                    convert_to_numpy=True
                )

                # Create FAISS index
                dimension = embeddings.shape[1]
                st.session_state.faiss_index = faiss.IndexFlatL2(dimension)
                st.session_state.faiss_index.add(embeddings.astype("float32"))
                st.session_state.processed_kb = True
                st.success(f"✅ Knowledge Base Loaded ({len(st.session_state.chunks)} chunks)")
            else:
                st.warning("No text could be extracted from the PDF or chunks were empty.")

# =====================================
# KNOWLEDGE BASE STATUS
# =====================================

if st.session_state.processed_kb:
    st.info(f"Knowledge base active with {len(st.session_state.chunks)} text chunks.")
else:
    st.warning("No study notes loaded. Please upload a PDF to get started.")

# =====================================
# AI TOOLS SECTION (Quiz Generator and Flashcard Generator)
# =====================================
st.markdown("## 📚 AI Tools")

# Quiz Generator
quiz_col_left, quiz_col_right = st.columns([0.6, 0.4])
with quiz_col_left:
    st.subheader("📝 Quiz Generator")
    quiz_button = st.button("📝 Generate Quiz", use_container_width=True, key="quiz_button")
with quiz_col_right:
    st.markdown("<div style='height: 35px;'></div>", unsafe_allow_html=True) # Spacer for alignment
    num_questions_selected = st.selectbox(
        "Number of Questions",
        [5, 10, 15, 20],
        key="main_quiz_questions"
    )
st.markdown("---") # Separator

# Flashcard Generator
flashcard_col_left, flashcard_col_right = st.columns([0.6, 0.4])
with flashcard_col_left:
    st.subheader("🃏 Flashcard Generator")
    flashcard_button = st.button("🃏 Generate Flashcards", use_container_width=True, key="flashcard_button")
with flashcard_col_right:
    st.markdown("<div style='height: 35px;'></div>", unsafe_allow_html=True) # Spacer for alignment
    num_flashcards = st.selectbox(
        "Number of Flashcards",
        [5, 10, 15, 20],
        key="flashcards"
    )

st.write("Ask questions from your study notes below or use the AI tools above.")

# =====================================
# RETRIEVAL FUNCTION
# =====================================

def retrieve_context(query):

    if st.session_state.faiss_index is None:
        return ""

    query_embedding = embed_model.encode(
        [query],
        convert_to_numpy=True
    )

    D, I = st.session_state.faiss_index.search(query_embedding, 5)

    context = ""

    for idx in I[0]:
        if idx != -1 and idx < len(st.session_state.chunks):
            context += st.session_state.chunks[idx]
            context += "\n\n"

    return context

# =====================================
# CHAT HISTORY DISPLAY
# =====================================

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])


# =====================================
# USER INPUT (CHAT)
# =====================================

question_for_chat = st.chat_input("💬 Ask your question")


# =====================================
# MAIN CHAT PROCESSING
# =====================================

if question_for_chat:
    st.session_state.messages.append(
        {
            "role": "user",
            "content": question_for_chat
        }
    )

    with st.chat_message("user"):
        st.markdown(question_for_chat)

    answer = ""
    if not st.session_state.processed_kb:
        answer = "Please upload your PDF notes first before asking questions."
    else:
        with st.spinner("🤖 Thinking..."):
            context = retrieve_context(question_for_chat)

            prompt = f"""
You are an AI Study Companion.

Answer ONLY using the context below.

If the answer is not found in the context, say:

"I couldn't find this information in your notes."

Context:

{context}

Question:

{question_for_chat}

Answer in simple language.
"""

            try:
                response = gemini.generate_content(prompt)
                answer = response.text
            except genai.types.BlockedPromptException as e:
                answer = f"Gemini Error: Your prompt was blocked due to safety concerns. Please refine your question. Details: {e}"
            except Exception as e:
                if "401 Unauthenticated" in str(e):
                    answer = "Gemini Error: API Key is invalid or unauthorized. Please check your GOOGLE_API_KEY in Streamlit secrets."
                else:
                    answer = f"Gemini Error: {e}"

    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": answer
        }
    )

    with st.chat_message("assistant"):
        st.markdown(answer)

    if st.session_state.processed_kb:
        with st.expander("📄 Retrieved Context"):
            st.write(context)

# =====================================
# QUIZ GENERATOR (Logic Triggered by Button)
# =====================================

if quiz_button:
    if not st.session_state.processed_kb:
        st.warning("Please upload your PDF notes first to generate a quiz.")
        st.stop()

    notes = "\n\n".join(st.session_state.chunks)

    quiz_prompt = f"""
You are an AI Quiz Generator.

Generate {num_questions_selected} multiple-choice questions from these notes.

Each question should have:

A.
B.
C.
D.

Also provide the correct answer.

Notes:

{notes}
"""

    with st.spinner("Generating Quiz..."):
        try:
            response = gemini.generate_content(quiz_prompt)

            st.subheader(f"📝 Generated Quiz ({num_questions_selected} Questions)")

            quiz_text = response.text
            # Split into questions based on pattern like "1. " or "2. "
            questions_raw = re.split(r'\n\n(?=\d+\.)', quiz_text.strip())

            for q_block in questions_raw:
                if q_block.strip():
                    parts = q_block.split("\nCorrect Answer: ", 1)
                    question_content = parts[0].strip()
                    correct_answer = parts[1].strip() if len(parts) > 1 else "N/A"

                    # Split the question_content into question stem and options
                    option_a_match = re.search(r'A\\.\\s', question_content)
                    if option_a_match:
                        question_stem = question_content[:option_a_match.start()].strip()
                        options_str = question_content[option_a_match.start():].strip()

                        st.markdown(f"**{question_stem}**") # Use bold for the question stem

                        # Split options_str by (B., C., D.) and also consider A. for the first one
                        options_list = re.findall(r'([A-D]\\.\\s.*?)(?=[A-D]\\.\\s|\\Z)', options_str, re.DOTALL)

                        # Display options in two columns
                        for i in range(0, len(options_list), 2):
                            cols = st.columns(2)
                            with cols[0]:
                                st.markdown(options_list[i].strip())
                            if i + 1 < len(options_list):
                                with cols[1]:
                                    st.markdown(options_list[i+1].strip())

                    else:
                        # Fallback if options cannot be parsed (e.g., if it's not an MCQ format)
                        st.markdown(f"**{question_content}**")

                    with st.expander("Show Answer"):
                        st.markdown(f"**Correct Answer:** {correct_answer}")
        except genai.types.BlockedPromptException as e:
            st.error(f"Quiz generation blocked due to safety concerns. Please refine your input. Details: {e}")
        except Exception as e:
            if "401 Unauthenticated" in str(e):
                st.error("Quiz generation failed: Google API Key is invalid or unauthorized. Please check your GOOGLE_API_KEY in Streamlit secrets.")
            else:
                st.error(f"Quiz generation failed: {e}")

# =====================================
# FLASHCARD GENERATOR (Logic Triggered by Button)
# =====================================

if flashcard_button:

    if not st.session_state.processed_kb:
        st.warning("Please upload your PDF notes first.")
        st.stop()

    notes = "\n\n".join(st.session_state.chunks)

    flash_prompt = f"""
You are an AI Flashcard Generator.

Generate {num_flashcards} study flashcards.

Rules:

• Each flashcard should have:

Flashcard 1

Question:
...

Answer:
...

• Keep answers short.
• Focus on important concepts.
• Make them suitable for quick revision.

Study Notes:

{notes}
"""

    with st.spinner("Generating Flashcards..."):

        try:

            response = gemini.generate_content(flash_prompt)

            st.subheader(f"🃏 {num_flashcards} Flashcards")

            with st.expander("🃏 Flashcards"):
                st.markdown(response.text)

        except genai.types.BlockedPromptException as e:
            st.error(f"Flashcard generation blocked due to safety concerns. Please refine your input. Details: {e}")
        except Exception as e:
            if "401 Unauthenticated" in str(e):
                st.error("Flashcard generation failed: Google API Key is invalid or unauthorized. Please check your GOOGLE_API_KEY in Streamlit secrets.")
            else:
                st.error(f"Flashcard generation failed: {e}")
